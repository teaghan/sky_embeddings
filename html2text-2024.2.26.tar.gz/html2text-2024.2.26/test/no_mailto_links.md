Send an email to me@example.com.
