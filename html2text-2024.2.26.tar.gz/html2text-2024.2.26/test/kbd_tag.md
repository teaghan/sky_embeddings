Press `[CTRL]+c` to copy.
