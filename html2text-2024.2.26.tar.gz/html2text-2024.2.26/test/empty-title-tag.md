[This is an A tag with an empty title property](test.html)
