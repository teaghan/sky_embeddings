_emphasis_

_emphasis:_ some text

_repeat:_ again

**bold**

**bold:** some text

**repeat:** again

~~strike~~

~~strike:~~ some text

~~strike:~~ again

separate _emphasis_ some more text

_emphasis_.

_emphasis_?

_emphasis_!

(_emphasis_)

[**bold**}

(~~strike~~]

* **bold**

~ ~~strike~~

_em1_ _em2_
