Definition List

    A list of terms and their definitions/descriptions.
Ordered List

    A numbered list.
Unordered List

    An unnumbered list.

#### Example 2

Vocals

    Bruce Dickinson
Guitar

    Adrian Smith
    Dave Murray
    Janick Gers
Bass

    Steve Harris
Drums

    Nicko McBrain

  * some item
  * Some other item
  * some item

  1. Some other item
  2. some item
  3. some item

  * something else here
  * some item
