One of the most common equations in all of physics is E=mc<sup>2</sup>.
