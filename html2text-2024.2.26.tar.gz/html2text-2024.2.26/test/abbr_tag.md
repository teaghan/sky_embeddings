TLA xyz

  *[TLA]: Three Letter Acronym
