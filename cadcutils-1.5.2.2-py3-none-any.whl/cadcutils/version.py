version = 'cadcutils 1.5.2.2'
